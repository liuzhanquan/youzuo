<?php
/**
 * Created by PhpStorm.
 * User: LHG
 * Date: 2019/8/10
 * Time: 14:20
 */

namespace lib;


class OrderStatus
{
        const ORDER_STATUS = [
            '0'=>'未付款',
            '1'=>'已取消',
            '2'=>'已收货',
            '3'=>'待收货',
            '4'=>'待发货',
            '5'=>'待付尾款',
            '6'=>'已退款',
        ];
        const ORDER_PAY_STATUS = [
            '1'=>'未支付',
            '2'=>'已支付',
            '3'=>'已退款',
        ];
}