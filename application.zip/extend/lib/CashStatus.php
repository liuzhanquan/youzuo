<?php
/**
 * Created by PhpStorm.
 * User: LHG
 * Date: 2019/8/10
 * Time: 18:22
 */

namespace lib;


class CashStatus
{
    const CASH_TYPE = [
        '1'=>'代理',
        '2'=>'会员',
    ];

    const CASH_STATUS = [
        '1'=>'待审核',
        '2'=>'审核通过',
        '3'=>'审核拒绝',
    ];

    const RECHARGE_MONEY_STATUS = [
        '1'=>'正常',
        '2'=>'禁止',
    ];

    const RECHARGE_ORDER_STATUS = [
            '1'=>'未支付',
            '2'=>'已支付',
        ];


    const AGENT_ORDER_STATUS = [
        '1'=>'已支付',
        '2'=>'未支付',
        '3'=>'审核中',
        '4'=>'已拒绝',
    ];

    const AGENT_ORDER_TYPE = [
        '1'=>'线上',
        '2'=>'线下',
    ];

    const CASH_PAY_TYPE = [
        '1'=>'银行卡',
        '2'=>'支付宝',
        '3'=>'微信',
    ];

    const AGENT_STATUS = [
        '0'=>'待审核',
        '1'=>'已通过',
        '2'=>'已拒绝',
    ];

    const MAKE_MONEY_STATUS = [
        '1'=>'待打款',
        '2'=>'打款中',
        '3'=>'已打款',
        '4'=>'已失败',
    ];
}