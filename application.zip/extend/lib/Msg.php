<?php 

namespace wechat;

class Msg{


	public function getUserLink($sitename,$str){
		$urlInfo = unlock_url($str);
		parse_str($urlInfo); // 返回结果 $uid 上级ID $link 邀请链接ID
		$userLink = db('user_link')->find($link);
		if(!empty($userLink)){
			$level = db('agent_level')->find($userLink['level_id']);
			// http://taiji.guangzhoubaidu.com/static/images/applyWx.jpg
			$msgData = array(
				array(
					'Title'=>$sitename.'邀请您申请代理授权',
					'Description'=>'申请的代理级别为：'.$level['name'],
					'PicUrl'=>'http://yy.kaifa123.net/static/images/applyWx.jpg',
					'Url'=>$userLink['local_url']
				),
			);
			return $msgData;
		}
		return false;
	}

}

?>