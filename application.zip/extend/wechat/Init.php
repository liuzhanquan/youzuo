<?php 

namespace wechat;

use \think\Controller;

class Init extends Controller {

	public function index(){
		echo 'wechat';
	}
}