<?php
/**
 * 全局辅助函数
 */

namespace core;

/**
 * 
 */
class Help{
	
    /**
     * 密码加密方法
     * @param string $pw 要加密的字符串
     * @return string
     */
    public static function sp_password($pw,$authcode=''){
        $result="###".md5(md5($authcode.$pw));
        return $result;
    }
    /**
     * 密码比较方法,所有涉及密码比较的地方都用这个方法
     * @param string $password 要比较的密码
     * @param string $password_in_db 数据库保存的已经加密过的密码
     * @return boolean 密码相同，返回true
     */
    public static function sp_compare_password($password,$password_in_db,$authcode = ''){
        if(strpos($password_in_db, "###")===0){
            return self::sp_password($password,$authcode)==$password_in_db;
        }else{
            return self::sp_password_old($password)==$password_in_db;
        }
    }
    /**
     * 密码加密方法 (X2.0.0以前的方法)
     * @param string $pw 要加密的字符串
     * @return string
     */
    public static function sp_password_old($pw,$authcode = ''){
        $decor=md5($authcode);
        $mi=md5($pw);
        return substr($decor,0,12).$mi.substr($decor,-4,4);
    }
}