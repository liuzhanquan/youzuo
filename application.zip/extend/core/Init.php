<?php

namespace core;
use \think\Controller;
use \app\common\model\Admin;
use \app\common\model\Group;
use \app\common\model\Menu;
use \app\common\model\Config;

class Init extends Controller{

	public $proxy = array();
	public $proxyGroup = array();
    public $data = array();
	public $config = array();

	/**
	 * 功能初始化
	 * @author Azaz QQ:826355918
	 * @DateTime 2019-03-24
	 * @param    [type]
	 * @return   [type]
	 */
	public function initialize(){
		parent::initialize();
		$this->checkLogin();
		$this->checkPurview();
		$this->getPath();
		$this->data = request()->param('',null,'htmlspecialchars');
	}


	/**
	 * 登录验证
	 * @author Azaz QQ:826355918
	 * @time   2018-12-11T19:15:43+0800
	 * @return [type]
	 */
	protected function checkLogin(){

		$rootName = request()->root();
		$rootPath = explode('/', $rootName);
		if(isset($rootPath[1])){
			$authUrl = request()->domain().'/auth/login';
		}else{
			$authUrl = url('/auth/login');
		}

		$userId = cookie('userId');
		if(!$userId){
			if(request()->isAjax()){
				return $this->error('请先登录',$authUrl);die;
			}else{
				return $this->redirect($authUrl);die;
			}
		}
        $config = Config::select();
        $configArr = [];
        if(!empty($config)){
            foreach($config as $k=>$vo){
                $configArr[$vo['name']] = $vo['value'];
            }
        }
        $this->config = $configArr;
        $this->assign('config',$configArr);
		$user = $this->proxy = Admin::where(['id'=>$userId])->find();
		$userGroup = $this->proxyGroup = Group::where(['id'=>$user->role_id])->find();
		$this->assign('proxy',$user);
		$this->assign('proxyGroup',$userGroup);
	}


    /**
     * 权限检测
     * @return bool
     */
    private function checkPurview() {
        $topKey = $this->request->controller(); // 控制器
        $action = $this->request->action(); // 操作方法
        $userRoleId = $this->proxy['role_id'];
        $roleGroup = Group::where('id',$userRoleId)->find();
        $menuInfo = Menu::where(['model'=>$topKey,'action'=>$action])->find();
        if($roleGroup['is_sys'] <> 1){
            // 栏目权限
            $menu = Menu::where('id','in',$roleGroup['menu_power'])->order('sort asc')->select();
            $powerArr = explode(',', $roleGroup['power']);
            $powerArr[] = 'Index/index';
            $delArr = array();
            foreach($powerArr as $vo){
                $powarr = explode('/', $vo);
                if(count($powarr) >= 3){
                    $delArr[] = $powarr[2];
                }
            }
            $menuPower = $topKey.'/'.$action;
            if($action == 'del'){
                // 判断删除权限
                $table = $this->data['table'];
                if(!in_array($table,$delArr)){
                    return $this->error(lang('role error'));
                }
            }else{
                if(!in_array($menuPower,$powerArr)){
                    return $this->error(lang('role error'));
                }
            }

        }else{
            // 超级管理员
            $menu = Menu::order('sort asc')->select();
        }
        foreach($menu as $k=>$vo){
            $menu[$k] = $vo;
            $menu[$k]['action'] = $vo['action'];
            if(empty($vo['extend'])){
                $extStr = $vo['action'];
            }else{
                $extStr = $vo['action'].','.$vo['extend'];
            }
            $menu[$k]['extend'] = explode(',', $extStr);
            $menu[$k]['url'] = url($vo['model'].'/'.$vo['action']);
        }
        $li = new \lib\PHPTree(['id', 'parent']);
        $list = $li->makeTree($menu,array('parent_key'=>'parent_id','expanded'=>true));
        $this->assign('topNav', $list);
    }
    private function getPath(){
        $topKey = $this->request->controller(); // 控制器
        $action = $this->request->action(); // 操作方法
        $data = Menu::select();
        $where = array(
            'model'=>$topKey,
            'action'=>$action,
        );
        $info = Menu::where($where)->find();
        if(empty($info)){
            $info = Menu::where([
                ['model','=',$topKey],
                ['extend','like','%'.$action.'%']
            ])->find();
        }
        $path = array();
        if(!empty($info)){
            $categroy = new \lib\Category(['id','parent_id','name','cname']);
            $path = $categroy->getPath($data,$info['id']);
        }
        $this->assign('path',$path);
    }
}