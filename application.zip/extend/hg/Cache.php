<?php
/**
 * Created by PhpStorm.
 * User: LHG
 * Date: 2019/4/18
 * Time: 12:08
 */

namespace hg;


class Cache
{
    //缓存名称前缀
    const CACHE_NAME_PREFIX = 'redis:';
    //zt:user
    //zt:user:id:1
    //用户表，id为1的列
    //zt:table:user:id:1:diff:lottery
    //keys(zt:user)
    //keys(zt:user:id)
    //前缀，表名，字段名，字段值,其他值
    //name expire
    //表级别的缓存，如配置信息
    //行级别的缓存，如单个用户的信息

    // 秒杀表
    const MS = 'table:ms:id';

    //抢购表
    const QG = 'table:qg:id';



    /**
     * 获取缓存key
     * @param $cache_name
     * @return string
     */
    public static function getCacheName($cache_name)
    {
        if (is_array($cache_name))
            $cache_name = str_replace('=', ':', http_build_query($cache_name, '', ':'));
        return self::CACHE_NAME_PREFIX . $cache_name;
    }

}

