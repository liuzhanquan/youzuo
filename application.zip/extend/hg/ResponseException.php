<?php
/**
 * Created by PhpStorm.
 * User: LHG
 * Date: 2019/4/15
 * Time: 0:21
 */

namespace hg;

use hg\Code;

/**
 * Class ResponseException
 * @package mercury
 *
 * 响应异常错误处理
 */
class ResponseException extends \Exception
{

    protected $info = 'information is empty';

    public function __construct($code = 20000, $message = '', $info = '')
    {

        if (empty($message)) {
            $code_arr   = Code::CODE_ARRAY;
            $message    = isset($code_arr[$code]['msg']) && !empty($code_arr[$code]['msg']) ? $code_arr[$code]['msg'] : '状态编码不存在！';
            $info       = isset($code_arr[$code]['info']) && !empty($code_arr[$code]['info']) ? $code_arr[$code]['info'] : 'information is empty';
        }
        if (!empty($info)) $this->info = $info;
        parent::__construct($message, $code);
    }

    /**
     * 返回数据
     *
     * @return array
     */
    public function getData()
    {
        return [
            'code'  => $this->getCode(),
            'msg'   => $this->getMessage(),
            'info'  => $this->getInfo(),
        ];
    }

    /**
     * 响应数据
     *
     * @param array|string $data
     * @return array
     */
    public function response($data)
    {
        $ret   = [
            'code'  => $this->getCode(),
            'msg'   => $this->getMessage(),
            'info'  => $this->getInfo(),
            'data'  => $data
        ];
        $this->writeLog($ret);
        return $ret;
    }

    /**
     * 获取info
     *
     * @return 错误信息|string
     */
    public function getInfo()
    {
        return $this->info;
    }

    public function writeLog(array $data)
    {
        //写入日志
        if ($this->getCode() == Code::CODE_SUCCESS) {
            $table  = 'response_success';
        } else {
            $table  = 'response_error';
        }

        $logs   = [
            'data'  => request()->param(),
            'app'   => request()->app,
            'user'  => request()->user,
            'ip'    => request()->ip,
            'response'  => $data,
        ];
        //执行写入日志操作..........
    }
}