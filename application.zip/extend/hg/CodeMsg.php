<?php
/**
 * Created by PhpStorm.
 * User: LHG
 * Date: 2019/4/15
 * Time: 14:50
 */

namespace hg;
/**
 * 提示信息配置在此文件
 */

class CodeMsg
{
    const CODE_SUCCESS     = '请求成功'; //返回成功提示信息
    const CODE_BAD_REQUEST     = '请求失败'; //返回请求失败提示信息
    const ORDER_CREATE_ERROR  = '订单创建失败'; //订单创建失败
    const CART_CREATE_ERROR  = '购物车创建失败'; //购物车创建失败
    const CART_UPDATE_ERROR  = '购物车保存失败'; //购物车保存失败
    const USER_UPDATE_ERROR  = '用户信息修改失败'; //用户信息修改失败
    const USER_CREATE_ERROR  = '用户信息保存失败'; //用户信息保存失败
    const ADDRESS_UPDATE_ERROR  = '收货地址保存失败'; //收货地址保存失败
    const ADDRESS_CREATE_ERROR  = '收货地址创建失败'; //收货地址创建失败
    const ADDRESS_DELETE_ERROR  = '收货地址删除失败'; //收货地址创建失败
    const MSGOODS_ERROR  = '秒杀失败'; //秒杀失败
    const STOCK_ERROR  = '库存不足'; //库存不足
    const ADDRESS_ERROR  = '收货地址错误'; //收货地址错误
    const COUPON_ERROR  = '优惠券使用错误'; //优惠券使用错误
    const COUPON_MONEY_ERROR  = '订单金额未达到优惠券要求'; //订单金额未达到优惠券要求
    const ORDER_PD_ERROR  = '剩余拼单数量不足'; //剩余拼单数量不足
    const ORDER_UP_ERROR  = '起拼量不足'; //剩余拼单数量不足
    const USER_CASH_ERROR  = '余额不足'; //余额不足
    const USER_CASH_MONEY_ERROR  = '提现金额超出或者不足最低提现金额'; //提现金额超出或者不足最低提现金额
    const CART_NOT_ERROR  = '未选择需要删除的购物车商品'; //提现金额超出或者不足最低提现金额
    const ORDER_DELETE_ERROR  = '该订单不能删除'; //提现金额超出或者不足最低提现金额
}