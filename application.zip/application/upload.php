<?php 
 return array (
  'upload_size' => '10',
  'upload_type' => 'jpg,gif,bmp,png,doc,xls,xlsx,pem,txt,jpeg,csv,mp4,rmvb,3gp,amv,avi',
  'thumb_status' => 0,
  'thumb_width' => '500',
  'thumb_height' => '500',
  'thumb_type' => '6',
  'watermark_status' => 0,
  'watermark_image' => 0,
  'watermark_local' => '8',
  'watermark_type' => '2',
  'watermark_text' => '',
  'watermark_text_size' => '20',
  'watermark_text_color' => '#CFCFCF',
);