<?php
/**
 * Created by PhpStorm.
 * User: LHG
 * Date: 2019/8/8
 * Time: 16:11
 */

namespace app\common\model;
use think\Model;

class Bank extends Model
{
    protected $table = 'bear_bank';
}