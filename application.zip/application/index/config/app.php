<?php 

return [

	'default_return_type'    => 'json'
];